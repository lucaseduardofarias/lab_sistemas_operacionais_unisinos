/*Artur Eduardo e Augusto Lumi*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>

void tratar(int n);
void printarmenu(pid_t _pidwb,pid_t _pidtxt, pid_t _pidterm, char _statuswb[],char _statustxt[], char _statusterm[], char _statusfinalizar[]);
void opcao();

#define clear() printf("\033[H\033[J");

int _opcao = 0; /*opcao do menu*/

pid_t _pidwb = 0; /*pid do web browser*/
pid_t _pidtxt = 0; /*pid do text editor*/
pid_t _pidterm = 0; /*pid do terminal*/

char _url[128]; /*url para abrir no navegador*/
char _statuswb[20] = "Parado"; /*status do web browser*/
char _statustxt[20] = "Parado"; /*status do text editor*/
char _statusterm[20] = "Parado"; /*status do terminal*/
char _statusfinalizar[20] = "Parado"; /*status do finalizar processo*/

void printarmenu(pid_t _pidwb,pid_t _pidtxt, pid_t _pidterm, char _statuswb[],char _statustxt[], char _statusterm[], char _statusfinalizar[]){	
	clear()
	_opcao = 0;
	
	//verifica se os processos estao executando
	if(_pidwb != 0){
		_statuswb = "Executando";
	}
	if(_pidtxt != 0){
		_statustxt = "Executando";
	}
	if(_pidterm != 0){
		_statusterm = "Executando";
	}
	
	printf("\n<<<< Applications Menu >>>>\n");
	printf("	1) Web browser (%s, pid=%d)\n",_statuswb,_pidwb);
	printf("	2) Text Editor (%s, pid=%d)\n",_statustxt,_pidtxt);
	printf("	3) Terminal (%s)\n",_statusterm);
	printf("	4) Finalizar processo (%s)\n",_statusfinalizar);
	printf("	5) Quit\n");
	
	//inicia o alarme para repetir o menu de 5 em 5 segundos
	alarm(5);
	
	//pergunta a opcao desejada
	printf("Opção: ");
	scanf("%d", &_opcao);
	
	//verificacao das opçoes para ver se sao validadas
	if(_opcao == 1 && _pidwb == 0){
		printf("\nInforme a URL: ");
		scanf("%s",_url);
			opcao();
	}
	else if(_opcao == 2 && _pidtxt == 0){
		opcao();
	}
	else if(_opcao == 3 && _pidterm == 0){
		opcao();
	}
	else if(_opcao == 4){
		opcao();
	}
	else if(_opcao == 5){
		exit(1);
	}
	
	printarmenu(_pidwb,_pidtxt,_pidterm,_statuswb,_statustxt, _statusterm, _statusfinalizar);
}

void tratar(int n){
	alarm(5);
}

void opcao(){
	switch(_opcao){
		//opcao = 1 para abrir o navegador na url desejada
		case 1:
			_pidwb = fork();
			if(_pidwb<0){
				strcpy(_statuswb,"Falhou");
			}
			else if(_pidwb==0){
				execl("/usr/bin/firefox", "/usr/bin/firefox", _url, (char*)NULL);
				_pidwb = getpid();
			}
			break;
		//opcao = 2 para abrir um editor de texto	
		case 2:
			_pidtxt = fork();
			if(_pidtxt<0){
				strcpy(_statustxt,"Falhou");
			}
			else if(_pidtxt == 0){
				execl("/usr/bin/gedit","/usr/bin/gedit",(char*)NULL);
				_pidtxt = getpid();
			}
			break;
		//opcao = 3 para abrir uma janela do terminal
		case 3:
			_pidterm = fork();
			if(_pidterm<0){
				strcpy(_statusterm,"Falhou");
			}
			else if(_pidterm == 0){
				char *cmd[] = {"/usr/bin/x-terminal-emulator","-e","x-terminal-emulator",NULL};
				execv(cmd[0],cmd);
			}
			break;
		//opçao = 4 para finalizar processo		
		case 4:
			printf("Qual processo deseja finalizar? ");
			int processo = 0;
			scanf("%d",&processo);
			switch(processo){
				case 1:
					kill(_pidwb,SIGTERM);
					strcpy(_statusfinalizar,"Concluído");
					_pidwb = 0;
					break;
				case 2:
					kill(_pidtxt,SIGTERM);
					strcpy(_statusfinalizar,"Concluído");
					_pidtxt = 0;
					break;
				case 3:
					kill(_pidterm,SIGTERM);
					strcpy(_statusfinalizar,"Concluído");
					_pidterm = 0;
					break;
				default:
					strcpy(_statusfinalizar,"Falhou");
					break;
			}
			break;
		default:
			break;
	}
	printarmenu(_pidwb,_pidtxt,_pidterm,_statuswb,_statustxt, _statusterm, _statusfinalizar);
}

int main(){
	//atualizar o menu de 5 em 5 segundos	
	struct sigaction sa;
	memset(&sa,0,sizeof(sa));
	sa.sa_handler=&tratar;
	if(sigaction(SIGALRM, &sa, NULL) != 0){
		perror("Erro no alarme");
		exit(-1);
	}
	
	//atualizar o menu quando CTRL + C
	if(sigaction(SIGINT, &sa, NULL) != 0){
		perror("Erro");
		exit(-1);
	}

	//atualizar ao término de um processo filho
	if(sigaction(SIGCHLD, &sa, NULL) != 0){
		perror("Erro");
		exit(-1);
	}

	//chama a funçao para começar a execuçao do menu
	printarmenu(_pidwb,_pidtxt,_pidterm,_statuswb,_statustxt, _statusterm, _statusfinalizar);
}