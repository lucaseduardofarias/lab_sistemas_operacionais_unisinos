//Lucas Eduardo Farias
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>

int qtdTotalVogais = 0;
int qtdTotalConsoantes = 0;
char* palavra = "";

void imprimeNaTela(int quantidadeTotalPalavras,int qtdTotalVogais, int qtdTotalConsoantes)
{

    printf("Nesse texto existem %d palavras\n",quantidadeTotalPalavras);
    printf("Nesse texto existem %d vogais\n",qtdTotalVogais);
    printf("Nesse texto existem %d consoantes\n",qtdTotalConsoantes);

}

int main(int argc, char *argv[])
{
    if (argc-1 > 0)
    {

        int quantidadeTotalPalavras = argc-1; //retira da contagem o \0

        for (int i = 1; i < argc; i++)
        {
            palavra = argv[i];

            for (int j = 0; palavra[j]!='\0'; j++)
            {

                if (palavra[j] == 'a' || palavra[j] == 'e' || palavra[j] == 'i' || palavra[j] == 'o' || palavra[j] == 'u' ||
		palavra[j] == 'A' || palavra[j] == 'E' || palavra[j] == 'I' || palavra[j] == 'O' || palavra[j] == 'U' )
                {
                    qtdTotalVogais++;
                }
                else
                {
                    qtdTotalConsoantes++;
                }
            }
        }
        imprimeNaTela(quantidadeTotalPalavras,qtdTotalVogais,qtdTotalConsoantes);
    }
    else
    {
        printf("Favor Informar um texto\n");
        exit(-1);
    }

    return 0;
}
