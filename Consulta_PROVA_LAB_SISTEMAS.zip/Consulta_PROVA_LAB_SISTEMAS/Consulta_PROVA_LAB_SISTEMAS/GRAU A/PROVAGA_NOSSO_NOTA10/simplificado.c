//Lucas Eduardo Farias
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
	printf("Isento do imposto de renda!\n");
	execl("/bin/date","date",NULL);
	exit(0);
}
