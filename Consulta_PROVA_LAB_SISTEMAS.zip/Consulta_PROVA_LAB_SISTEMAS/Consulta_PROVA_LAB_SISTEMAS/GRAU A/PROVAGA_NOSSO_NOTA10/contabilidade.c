//Lucas Eduardo Farias
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/wait.h>


int status;
float salarioAnual,salarioMedio;

void tratador(int signum)
{
    switch(signum)
    {
    case SIGUSR1:
        printf("Sinal recebido. Aguardar a conclusao do processo filho!\n");
        break;
    case SIGUSR2:
        printf("Sinal recebido. Ainda em processamento...\n");
        break;
    case SIGINT:
        printf("Sinal recebido. Obrigado por utilizar o contabilidade!\n");
        exit(-1);
    case SIGTERM:
        printf("Sinal recebido. Obrigado por utilizar o contabilidade!\n");
        exit(-1);
    }
}

void instalador_sinal()
{

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));

    sa.sa_handler = &tratador;

    if(sigaction(SIGUSR1, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGUSR1\n");
        exit(-1);
    }
    if(sigaction(SIGUSR2, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGUSR1\n");
        exit(-1);
    }
    if(sigaction(SIGTERM, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGTERM\n");
        exit(-1);
    }
    if(sigaction(SIGINT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGINT\n");
        exit(-1);
    }

}

void verificaValorDigitado(float salarioMedio)
{

    if(salarioMedio < 3000)
    {
        pid_t pid = fork();
        switch(pid)
        {
        case -1:
            perror("Ocorreu um erro com o FORK(ERRO)\n");
            exit(-1);
            break;
        case 0:
            printf("Processo Filho: meu PID = %d e PPID = %d\n",getpid(),getppid());
            execl("./simplificado","simplificado",NULL);
            break;
        default:
             //dafault sempre o case do pai
            printf("Pai: meu PID = %d e PPID = %d\n",getpid(),getppid());
            pid = wait(&status);
            printf("Processo Pai: Filho (PID = %d) terminou com status %d\n",pid,WEXITSTATUS(status));
        }
    }
    else
    {
        pid_t pid = fork();
        switch(pid)
        {
        case -1:
            perror("Erro no fork\n");
            exit(-1);
            break;
        case 0:
            printf("Processo Filho: meu PID = %d e PPID = %d\n",getpid(),getppid());
            execl("/usr/bin/firefox","firefox","www.receita.fazenda.gov.br",NULL);
            break;
        default:
            //dafault sempre o case do pai
            printf("Processo Pai: meu PID = %d e PPID = %d\n",getpid(),getppid());
            pid = wait(&status);
            printf("Prcesso Pai: Filho (PID = %d) terminou com status %d\n",pid,WEXITSTATUS(status));
        }
    }

}


int main()
{

    instalador_sinal();

    printf("Favor informar o salario anual: \n");

    scanf("%f",&salarioAnual);

    while(salarioAnual < 0 || salarioAnual > 120000)
    {
        printf("Informe um valor valido!\n");
        printf("Favor informar o salario anual: ");
        scanf("%f",&salarioAnual);
    }

    float salarioMedio = salarioAnual/12;

    verificaValorDigitado(salarioMedio);


    sleep(2);
    return 0;
}
