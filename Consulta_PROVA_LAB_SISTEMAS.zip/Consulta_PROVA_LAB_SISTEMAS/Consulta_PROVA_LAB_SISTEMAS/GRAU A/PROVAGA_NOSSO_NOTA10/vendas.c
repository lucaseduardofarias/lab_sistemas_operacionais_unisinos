//Lucas Eduardo Farias
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int quantidadeProdutos;
float precoUnitario;

float custoTotalProduto()
{
    float custoTotal = quantidadeProdutos * precoUnitario;
    return custoTotal;
}

float MargemDeContribuicao()
{
    float margem = custoTotalProduto() * 0.5;
    return margem;
}

float ICMS()
{
    float icms = ((custoTotalProduto()+MargemDeContribuicao())*0.17);
    return icms;
}

float calcularValorDeVenda()
{
    float valorVendaProduto = custoTotalProduto()+MargemDeContribuicao()+ICMS();
    return valorVendaProduto;
}

void imprimeInformacao()
{

    printf ("**************** Informações ***************************\n");
    printf("O custo total do produto: R$ %5.2f (%d x R$ %5.2f)\n",custoTotalProduto(),quantidadeProdutos,precoUnitario);
    printf("O valor de margem de contribuicao: R$ %5.2f\n",MargemDeContribuicao());
    printf("O valor do ICMS do produto: R$ %5.2f\n",ICMS());
    printf("O valor de venda do produto: R$ %5.2f\n",calcularValorDeVenda());
    printf ("********************************************************\n");

}

int main()
{
    printf("Favor informar a quantidade de Produtos: ");
    scanf("%d",&quantidadeProdutos);

    while(quantidadeProdutos <= 0)
    {
        printf("O valor digitado não pode ser 0 ou inferior, favor digitar novamente: ");
        scanf("%d",&quantidadeProdutos);
    }

    printf("Favor informar o valor unitario do Produto: ");
    scanf("%f",&precoUnitario);

    while(precoUnitario <= 0)
    {
        printf("O valor digitado não pode ser 0 ou inferior, favor digitar novamente: ");
        scanf("%d",&quantidadeProdutos);
    }

    imprimeInformacao();
    return 0;
}
