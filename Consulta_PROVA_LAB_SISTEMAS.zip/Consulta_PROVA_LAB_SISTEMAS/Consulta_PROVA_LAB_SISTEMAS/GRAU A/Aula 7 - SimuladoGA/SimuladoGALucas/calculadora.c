#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void soma(int valor1, int valor2)
{
    printf("Resultado: %d\n", valor1 + valor2);
}

void subtracao(int valor1, int valor2)
{
    printf("Resultado: %d\n", valor1 - valor2);
}

void multiplicacao(int valor1, int valor2)
{
    printf("Resultado: %d\n", valor1 * valor2);
}

void divisao(int valor1, int valor2)
{
    printf("Resultado: %d\n", valor1 / valor2);
}

void exibeMenu()
{
    sleep(1);
    system("clear\n");
    printf("A - Soma\n");
    printf("B - Subtração\n");
    printf("C - Produto\n");
    printf("D - Divisão\n");
    printf("S - Sair\n" );

}
int main()
{
    char escolha;
    int valor1,valor2;

    while(escolha != 'S')
    {
        exibeMenu();

        printf("Quais das operações deverá ser executada:\n");
        scanf("%c", &escolha);
        getchar();

        if(escolha == 'S')
        {
            printf("Saindo da Calculadora");
            return 1;
        }

        printf("Digite o valor1:\n");
        scanf("%d", &valor1);
        getchar();

        printf("Digite o valor2:\n");
        scanf("%d", &valor2);
        getchar();

        switch (escolha)
        {
        case 'A':

            soma(valor1, valor2);
            break;

        case 'B':
            subtracao(valor1, valor2);
            break;

        case 'C':
            multiplicacao(valor1, valor2);
            break;

        case 'D':
            divisao(valor1, valor2);
            break;

        default:
            printf("Valor inválido, digite A, B, C, D ou S!\n");
        }
    }

    return 0;
}
