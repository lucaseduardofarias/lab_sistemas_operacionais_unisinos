#!/bin/bash
OPCAO=0
while [[ $OPCAO != 5 ]]; do

echo "**************** CANIVETE SUICO ****************"
echo "1 - Calculadora"
echo "2 - Análise de texto"
echo "3 - Automação de operações"
echo "4 - Gestão de processos"
echo "5 - Sair"
echo "************************************************"
echo "Digite a opção desejada:"
read OPCAO
echo "************************************************"

if [ $OPCAO = 1 ]; then
  gcc -Wall calculadora.c -o calculadora
  ./calculadora
elif [ $OPCAO = 2 ]; then
  echo "Digite uma palavra:"
  read palavra
  gcc -Wall texto.c -o texto
  ./texto $palavra
elif [ $OPCAO = 3 ]; then
  echo "Digite os 3 comandos: "
  read argumento
  gcc -Wall automacao.c -o automacao
  ./automacao $argumento
elif [ $OPCAO = 4 ]; then
  gcc -Wall gestao.c -o gestao;
  ./gestao
elif [ $OPCAO = 5 ]; then
  exit 0
fi
done




##if [ -d "$MON_DIR" ]; then
#	echo "Existe"
#else
#	echo "Não existe"
#	exit 2
#fi
