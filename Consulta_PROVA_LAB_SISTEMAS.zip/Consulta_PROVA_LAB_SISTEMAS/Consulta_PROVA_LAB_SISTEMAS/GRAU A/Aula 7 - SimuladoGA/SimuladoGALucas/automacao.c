#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{

	for (int i=3;i>=1;i--)
	{
		system(argv[i]);
		system("sleep 5");
	}
	printf("\n");
	system("date");
	printf("Processamento concluído! Obrigado\n");
	
	return 0;
}
