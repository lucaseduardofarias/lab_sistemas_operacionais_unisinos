#include <stdio.h>
#include <stdlib.h>

int main(int qtd, char *args[])
{
	int i;
	for (i = 3; i >= 1; i--)
	{
		printf("\nComando %d: \n\n", i);
		system(args[i]);
		system("sleep 5");
	}
	printf("\n");
	printf("Obrigado!\n");
	system("date");
	
	return 0;
}
