#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void somar(int a, int b){
	int soma = a + b;
	system("clear\n");
	printf("\nO resultado é: %d\n",soma);
}

void substrair(int a, int b){
	int subtracao = a - b;
	system("clear\n");
	printf("\nO resultado é: %d\n",subtracao);
}

void multiplicar(int a, int b){
	int produto = a * b;
	system("clear\n");
	printf("\nO resultado é: %d\n",produto);
}

void dividir(int a, int b){
	int divisao = a / b;
	system("clear\n");
	printf("\nO resultado é: %d\n",divisao);
}

int main()
{
	char operacao;
	int valora;
	int valorb;
    while (operacao != 'S')
    {
	printf("\n<<<< CALCULADORA >>>>\n");
	printf("\nA - Soma\n");
	printf("B - Subtração\n");
	printf("C - Produto\n");
	printf("D - Divisão\n");
	printf("S - Sair\n");

        printf("Digite a operação desejada: ");

        scanf("%c",&operacao);
	getchar();

	if (operacao == 'S'){
		system("clear\n");
		return 1;
	}

	printf("\nInforme o valor A desejado: ");
	
	scanf("%d",&valora);
	getchar();
	printf("\nInforme o valor B desejado: ");
	
	scanf("%d",&valorb);
	getchar();
         switch(operacao)
	    {
	    case 'A':
		somar(valora,valorb);
		break;
	    case 'B':
		substrair(valora,valorb);
		break;
	    case 'C':
		multiplicar(valora,valorb);
		break;
	    case 'D':
		dividir(valora,valorb);
		break;
	    }
    }
    
    return(1);

}
