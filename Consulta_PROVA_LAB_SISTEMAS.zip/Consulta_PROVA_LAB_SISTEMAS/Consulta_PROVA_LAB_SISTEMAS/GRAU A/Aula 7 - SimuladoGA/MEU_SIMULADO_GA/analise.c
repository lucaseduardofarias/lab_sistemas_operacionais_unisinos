#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

char* palavra;

void tratador(int signum){
	size_t tamanho = strlen(palavra);
	int cont = 0;
	switch(signum){
		case SIGUSR1:
			
			for(int i = 0; i < tamanho; i++){
				if(palavra[i] == 'A' || palavra[i] == 'a'){
					cont++;
				}
				if(palavra[i] == 'E' || palavra[i] == 'e'){
					cont++;
				}
				if(palavra[i] == 'I' || palavra[i] == 'i'){
					cont++;
				}
				if(palavra[i] == 'O' || palavra[i] == 'o'){
					cont++;
				}
				if(palavra[i] == 'U' || palavra[i] == 'u'){
					cont++;
				}
			}
			printf("Há %d vogais\n",cont);
			break;
		case SIGUSR2:
			printf("Há %d de dígitos na palavra\n",tamanho);
			break;
		case SIGINT:
			printf("\nEnvie um SIGTERM para encerrar\n");
			break;
		case SIGTERM:
			exit(0);
			break;
		default:
			printf("Não deve entrar aqui");
	}
}
	
int main(int qtd, char *args[]){
	struct sigaction sa;
	sigset_t mask;
	memset(&sa, 0, sizeof(sa));

	sa.sa_handler = &tratador;

	
	if(sigaction(SIGUSR1, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR1");
		exit(-1);
	}
	if(sigaction(SIGUSR2, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR1");
		exit(-1);
	}
	
	if(sigaction(SIGINT, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGINT");
		exit(-1);
	}
	
	if(sigaction(SIGTERM, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGINT");
		exit(-1);
	}
	sigfillset(&mask);
	sigdelset(&mask,SIGUSR1);
	sigdelset(&mask,SIGUSR2);
	sigdelset(&mask,SIGINT);
	sigdelset(&mask,SIGTERM);

	if (qtd > 0){
		palavra = args[1];
		printf("Meu PID = %d\n", getpid());
		printf("Palavra recebida: %s \n", palavra);
		printf("Envie um sinal\n");

		while(1){}
	}else{
		printf("Palavra não recebida\n");	
	}

	return 0;
}
