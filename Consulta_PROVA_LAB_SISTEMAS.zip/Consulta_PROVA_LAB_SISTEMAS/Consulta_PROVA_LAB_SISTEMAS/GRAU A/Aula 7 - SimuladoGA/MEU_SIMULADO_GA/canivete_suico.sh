#!/bin/bash

op=0;

while [ $op != 5 ]; do
	echo "************* CANIVETE SUICO *************"
	echo "1 - Calculadora"
	echo "2 - Análise de texto"
	echo "3 - Automação de operações"
	echo "4 - Gestão de processos"
	echo "5 - Sair\n"
	echo "******************************************"
	echo "Digite a opção desejada:"
	read op
	echo "******************************************"
	if [ $op = 1 ]; then
		gcc -Wall Calculadora.c -o Calculadora;
		./Calculadora;
	elif [ $op = 2 ]; then
		echo "Informe a palavra desejada: ";
		read palavra;
		gcc -Wall analise.c -o analise;
		./analise $palavra;
	elif [ $op = 3 ]; then
		echo "Informe o primeiro parâmetro: "
		read par1;
		echo "Informe o segundo parâmetro: "
		read par2;
		echo "Informe o terceiro parâmetro: "
		read par3;
		gcc -Wall automocao.c -o automocao;
		./automocao $par1 $par2 $par3;
	elif [ $op = 4 ]; then
		gcc -Wall gestao.c -o gestao;
		./gestao;
	elif [ $op = 5 ]; then
		exit 0;
	fi

done
