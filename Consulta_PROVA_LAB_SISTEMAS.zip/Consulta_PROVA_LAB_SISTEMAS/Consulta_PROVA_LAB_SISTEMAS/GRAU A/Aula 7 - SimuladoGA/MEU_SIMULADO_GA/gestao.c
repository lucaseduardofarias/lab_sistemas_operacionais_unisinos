#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int qtd, char *args[])
{
	int valorRecebido = 0;
	int statusTerminacao;
	pid_t pid;

	switch(fork()){
	case -1:
		perror("Erro na criação do fork\n");
		exit(-1);
		break;
	case 0:
		printf("Filho: Meu PID = %d\n", getpid());

		printf("Digite um valor: ");
		scanf("%d",&valorRecebido);
		if(valorRecebido >= 0 && valorRecebido <= 10){
			exit(0);
		}else{
			exit(10);
		}
		break;
	default:
		printf("PID do Pai: %d\n", getpid());
		pid = wait(&statusTerminacao);
		printf("Pai: filho (PID = %d) terminou com status de terminação = %d \n", pid, (WEXITSTATUS(statusTerminacao)));
		if (statusTerminacao == 0){
			printf("-- Sucesso");
		}else{
			printf("-- Falhou");
		}
	}
	printf("\nO pai terminou e seu PID é %d\n", getpid());

	sleep(1);
	return 0;
}
