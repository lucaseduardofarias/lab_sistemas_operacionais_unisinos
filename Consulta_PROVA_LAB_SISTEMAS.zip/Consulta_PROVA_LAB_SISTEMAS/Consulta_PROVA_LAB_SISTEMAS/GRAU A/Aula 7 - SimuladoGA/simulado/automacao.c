#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

void main(int qtd, char *args[]){
	char par1[10];
	strcpy(par1,arg[3]);
	
	char par2[10];
	strcpy(par2,arg[2]);
	
	char par3[10];
	strcpy(par3,arg[1]);
	
	system(par1);
	sleep(5);
	
	system(par2);
	sleep(5);
	
	system(par3);
	sleep(5);
	
	printf("Obrigado!\n");
	sleep(5);
	system("date");
}