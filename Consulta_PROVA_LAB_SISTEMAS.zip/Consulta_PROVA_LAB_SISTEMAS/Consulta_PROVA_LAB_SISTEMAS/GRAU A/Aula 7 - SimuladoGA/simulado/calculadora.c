#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

void sair(){
	exit(1);
}

void somar(int a, int b){
	int soma = a + b;
	printf("\nO resultado é: %d\n",soma);
	sair();
}

void substrair(int a, int b){
	int subtracao = a - b;
	printf("\nO resultado é: %d\n",subtracao);
	sair();
}

void multiplicar(int a, int b){
	int produto = a * b;
	printf("\nO resultado é: %d\n",produto);
	sair();
}

void dividir(int a, int b){
	if(a == 0 && b == 0){
		sair();	
	}
	int divisao = a / b;
	printf("\nO resultado é: %d\n",divisao);
	sair();
}

void main(){
	printf("A - Soma\n");
	printf("B - Subtração\n");
	printf("C - Produto\n");
	printf("D - Divisão\n");
	printf("S - Sair\n");

	printf("\nInforme a operação desejada: ");
	char op[2];
	scanf("%s",op);

	printf("\nInforme o valor A desejado: ");
	int valora;
	scanf("%d",&valora);

	printf("\nInforme o valor B desejado: ");
	int valorb;
	scanf("%d",&valorb);

	if(*op == 'A'){
		//soma
		somar(valora,valorb);
	}
	else if(*op == 'B'){
		//substrair
		substrair(valora,valorb);
	}
	else if(*op == 'C'){
		//produto
		multiplicar(valora,valorb);
	}
	else if(*op == 'D'){
		//divisão
		dividir(valora,valorb);
	}
	else if(*op == 'S'){
		//sair
		sair();
	}
	else{
		printf("Opção inválida. Execução terminada.");
		sair();
	}
}