#!/bin/bash

OPCAO=0

while [ $OPCAO != 5 ]; do
	echo "**************** CANIVETE SUICO ****************"
	echo "1 - Calculadora"
	echo "2 - Análise de texto"
	echo "3 - Automação de operações"
	echo "4 - Gestão de processos"
	echo "5 - Sair"
	echo "************************************************"
	echo "Digite a opção desejada:"
	read OPCAO
	echo "************************************************"

	if [ $OPCAO = 1 ]; then
		gcc -Wall calculadora.c -o calculadora;
		./calculadora;
	elif [ $OPCAO = 2 ]; then
		echo "Informe a palavra desejada: ";
		read palavra;
		gcc -Wall analise.c -o analise;
		./analise $palavra;
	elif [ $OPCAO = 3 ]; then
		echo "Informe o primeiro parâmetro: "
		read par1;
		echo "Informe o segundo parâmetro: "
		read par2;
		echo "Informe o terceiro parâmetro: "
		read par3;
		gcc -Wall automacao.c -o automacao;
		./automacao $par1 $par2 $par3;
	elif [ $OPCAO = 4 ]; then
		echo "Informe um valor inteiro: "
		read valor;
		gcc -Wall gestao.c -o gestao;
		./gestao $valor;
	elif [ $OPCAO = 5 ]; then
		exit 0;
	fi
done