#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

void main(int qtd, char *args[]){
	switch(fork()){
		case -1:
			perror("Erro na criação\n!");
			exit(-1);
			break;
		case 0:
			printf("PID do filho: %d",getpid());
			if(args[1] >= 0 && args[1] <= 10){
				exit(0);
			}
			else{
				exit(10);
			}
			break;
		default:
			printf("PID do pai: %d",getpid());
			pid=wait(&status);
			printf("Pai: filho (PID = %d) que terminou com status %d",pid,WEXITSTATUS(status));
	}
	printf("O pai terminou e seu PID é %d",getpid());
	return 0;
}