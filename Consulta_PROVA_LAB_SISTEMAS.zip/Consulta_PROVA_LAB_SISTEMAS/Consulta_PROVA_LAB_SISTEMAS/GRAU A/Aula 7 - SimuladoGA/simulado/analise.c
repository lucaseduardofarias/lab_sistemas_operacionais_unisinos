#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

char _palavra[100];

void tratador(int signum){
	size_t tamanho = strlen(_palavra);
	switch(signum){
		case SIGUSR1:
			int cont = 0;
			char vogais[100];
			for(int i = 0; i < tamanho; i++){
				if(_palavra[i] == 'A' || _palavra[i] == 'a'){
					cont++;
				}
				if(_palavra[i] == 'E' || _palavra[i] == 'e'){
					cont++;
				}
				if(_palavra[i] == 'I' || _palavra[i] == 'i'){
					cont++;
				}
				if(_palavra[i] == 'O' || _palavra[i] == 'o'){
					cont++;
				}
				if(_palavra[i] == 'U' || _palavra[i] == 'u'){
					cont++;
				}
			}
			break;
			printf("Há %d vogais\n",cont);
		case SIGUSR2:
			printf("Há %d de dígitos na palavra\n",tamanho);
			break;
		case SIGINT:
			printf("Envie um SIGTERM para encerrar\n");
			break;
		case SIGTERM:
			exit(0);
			break;
		default:
			printf("Não deve entrar aqui");
	}
}
	
void main(int qtd, char *args[]){
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));

	sa.sa_handler = &tratador;

	strcpy(_palavra, args[1]);
	
	printf("Meu PID = %d\n", getpid());
	printf("Palavra recebida: %s\n", *args[1]);
	printf("Envie um sinal\n");
	
	if(sigaction(SIGUSR1, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR1");
		exit(-1);
	}
	if(sigaction(SIGUSR2, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR1");
		exit(-1);
	}
	
	if(sigaction(SIGINT, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGINT");
		exit(-1);
	}
	
	if(sigaction(SIGTERM, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGINT");
		exit(-1);
	}
}