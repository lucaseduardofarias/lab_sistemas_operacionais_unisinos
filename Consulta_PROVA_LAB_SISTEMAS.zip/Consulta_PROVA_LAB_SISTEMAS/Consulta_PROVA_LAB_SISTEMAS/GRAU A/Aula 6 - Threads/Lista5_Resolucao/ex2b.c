#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>

#define NUM_THREADS 4

struct WorkUnit
{
	int n1;
	int n2;
	int iOp;
	int cOp;
	float result;
};

void *Operacao(void *param)
{
	struct WorkUnit *wu = param;

	int n1 = wu->n1;
	int n2 = wu->n2;
	int op = wu->iOp;

	switch (op)
	{
	   case 0:
		wu->result = n1 + n2;
		wu->cOp = '+';	
	   break;

	   case 1:
		wu->result = n1 - n2;
		wu->cOp = '-';	
	   break;

	   case 2:
		wu->result = n1 * n2;
		wu->cOp = '*';	
	   break;

	   case 3:
		wu->result = n1 / n2;
		wu->cOp = '/';	
	   break;

	}

	pthread_exit((void *)wu);
}

int main(int argc, char *argv[])
{
	if (argc != 3)
	{
		perror("Informe os 2 valores por linha de comando!\n");
		return 1;
	}

	//void *(*functions[NUM_THREADS])(void *) = {Soma, Subtracao, Multiplicacao, Divisao};

	pthread_t thread[NUM_THREADS];
	struct WorkUnit wunits[NUM_THREADS];
	struct WorkUnit *w;
	struct WorkUnit *status;
	pthread_attr_t attr;
	int rc, t;

	int n1 = atoi(argv[1]);
	int n2 = atoi(argv[2]);

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

	for (t = 0; t < NUM_THREADS; t++)
	{
		w = &wunits[t];
		w->n1 = n1;
		w->n2 = n2;
		w->iOp = t;

		rc = pthread_create(&thread[t], &attr, &Operacao, w);
		if (rc)
		{
			errno = rc;
			perror("Erro na criacao da Thread!");
			exit(EXIT_FAILURE);
		}
	}

	pthread_attr_destroy(&attr);

	for (t = 0; t < NUM_THREADS; t++)
	{
		rc = pthread_join(thread[t], (void *)&status);
		if (rc)
		{
			errno = rc;
			perror("Erro no Join!");
			exit(EXIT_FAILURE);
		}

		printf("Resultado da operação %c eh: %f\n", status->cOp, status->result);
	}

	pthread_exit(NULL);
}
