#!/bin/bash
if [ -d "$MON_DIR" ]; then
	echo "Existe"
else
	echo "Não existe"
	exit 2
fi
