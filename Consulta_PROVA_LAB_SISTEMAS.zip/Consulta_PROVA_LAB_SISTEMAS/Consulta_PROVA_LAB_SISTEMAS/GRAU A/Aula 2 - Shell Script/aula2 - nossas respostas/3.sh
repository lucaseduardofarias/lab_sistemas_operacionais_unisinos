#!/bin/bash
echo "Digite um comando:"
read comando
echo "Digite um parâmetro:"
read param1
echo "Digite um parâmetro:"
read param2
echo "Digite um parâmetro:"
read param3

dirA=$MON_DIR
dirB=$dirA

if [ -d "$MON_DIR" ]; then
	ls $dirA > listaA.txt
	while [ true ]; do
		ls $dirB > listaB.txt
		diff -rq listaA.txt listaB.txt > dif.txt
		if [ -s "./dif.txt" ]; then
			eval $"$comando" "$param1" "$param2" "$param3"
			mv listaB.txt listaA.txt
		fi
		sleep 2
	done
else
	echo "Não existe"
	exit 2
fi
