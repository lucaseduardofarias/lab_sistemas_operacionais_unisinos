#!/bin/bash
if [ -d "$MON_DIR" ]; then
	cd $MON_DIR
	while [ true ]; do
		clear
		ls
		sleep 2
	done
else
	echo "Não existe"
	exit 2
fi
