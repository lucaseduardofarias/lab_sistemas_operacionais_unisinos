//Autores LUCAS EDUARDO FARIAS, MAITHE MELLO
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>


//variaiaveis globais
struct sigaction sa;

sigset_t conjuntoSinais;
sigset_t conjuntoSinaisAntigos;

int  opcao_escolhida = 0;
int opcaokill = 0;

struct atributos
{
    pid_t webPID;               /*pid do web browser*/
    pid_t editorPID;            /*pid do text editor*/
    pid_t terminalPID;          /*pid do terminal*/

    char webSTATUS[60];         /*status do web browser*/
    char editorSTATUS[60];      /*status do text editor*/
    char terminalSTATUS[60];    /*status do terminal*/
    char finalizarSTATUS[60];   /*status do finalizar processo*/

} registroProcessos;

void tratador_sinal(int signum)
{
    pid_t pid = 0;
    int status;
    char *statusConcluido = "Concluído";

    //verifica os sinais dos processos
    if(signum == SIGINT || signum == SIGALRM || signum == SIGCHLD)
    {
        //verifica se existe algum filho zumbi se passar o -1 como parametro do waitpid
        pid = waitpid(-1, &status, WNOHANG);

        //se for 0 acabou normalmente
        if(pid == 0)
        {
            return;
        }

        if(pid == registroProcessos.webPID && ((strcmp(registroProcessos.webSTATUS, statusConcluido)) != 0))
        {
            //reseta o pid, para criação de novos processos.
            registroProcessos.webPID = 0;
            //copia para dentro de webStatus o valor "Abortado"
            strcpy(registroProcessos.webSTATUS, "Abortado");

        }
        else if(pid == registroProcessos.editorPID && ((strcmp(registroProcessos.editorSTATUS, statusConcluido)) != 0))
        {

            registroProcessos.editorPID = 0;
            strcpy(registroProcessos.editorSTATUS, "Abortado");
        }
        else if(pid == registroProcessos.terminalPID && ((strcmp(registroProcessos.terminalSTATUS, statusConcluido)) != 0))
        {

            registroProcessos.terminalPID = 0;
            strcpy(registroProcessos.terminalSTATUS, "Abortado");
        }
    }
}

void sinais()
{
    sigemptyset(&conjuntoSinais);       //seta para o conjuntoSinais quais os sinais ele deve ouvir
    sigaddset(&conjuntoSinais, SIGINT); //seta  que conjuntoSinais ira ouvir tal sinal
    sigaddset(&conjuntoSinais, SIGCHLD);
    sigaddset(&conjuntoSinais, SIGALRM);

    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = &tratador_sinal;

    //fica ouvindo os sinais
    if(sigaction(SIGCHLD, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGCHLD");
        exit(-1);
    }

    if(sigaction(SIGINT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGINT");
        exit(-1);
    }

    if(sigaction(SIGALRM, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGALRM");
        exit(-1);
    }
}

void cria_processo_programa(char *caminho, char *programa, char *url)
{

    pid_t pid;


    if((pid = fork()) < 0)
    {
        perror("Erro na criacao do processo!");
    }
    else if(pid == 0)
    {
        sigprocmask(SIG_BLOCK, &conjuntoSinais, &conjuntoSinaisAntigos);

        if(url != NULL)
        {
            execlp(caminho, programa, url, NULL);
        }
        else
        {
            execlp(caminho, programa,NULL);
        }

    }
    else
    {

        switch(opcao_escolhida)
        {
        case 1:
            registroProcessos.webPID = pid;
            sprintf(registroProcessos.webSTATUS, "Executando, PID=%d", registroProcessos.webPID);
            break;
        case 2:
            registroProcessos.editorPID = pid;
            sprintf(registroProcessos.editorSTATUS, "Executando, PID=%d", registroProcessos.editorPID);
            break;
        case 3:
            registroProcessos.terminalPID = pid;
            sprintf(registroProcessos.terminalSTATUS, "Executando, PID=%d", registroProcessos.terminalPID);
            break;
        }

    }
}

void menuAplicacao(void)
{
    opcao_escolhida = 0;

    system("clear\n");
    printf("<<<< Aplications Menu >>>>\n");
    printf("1) - Web Browser (%s)\n", registroProcessos.webSTATUS);
    printf("2) - Text Editor (%s)\n", registroProcessos.editorSTATUS);
    printf("3) - Terminal (%s)\n", registroProcessos.terminalSTATUS);
    printf("4) - Finalizar Processo (%s)\n", registroProcessos.finalizarSTATUS);
    printf("5) - Quit\n");
}

void finaliza_processo (int pidkill, char status[100], int opcao)
{

    //finaliza o processo e captura o status do kill
    int statusFinalizacao = kill(pidkill, SIGTERM);

    if(statusFinalizacao == 0)
    {

        if (opcao == 1)
        {
            strcpy(registroProcessos.webSTATUS, "Concluído");
            strcpy(registroProcessos.finalizarSTATUS, "Concluído");
        }
        else if (opcao == 2)
        {
            strcpy(registroProcessos.editorSTATUS, "Concluído");
            strcpy(registroProcessos.finalizarSTATUS, "Concluído");
        }
        else if (opcao == 3)
        {
            strcpy(registroProcessos.terminalSTATUS, "Concluído");
            strcpy(registroProcessos.finalizarSTATUS, "Concluído");
        }

    }
    else if (statusFinalizacao == -1)
    {


        if (opcao == 1)
        {
            strcpy(registroProcessos.webSTATUS, "Falhou");
        }
        else if (opcao == 2)
        {
            strcpy(registroProcessos.editorSTATUS, "Falhou");
        }
        else if (opcao == 3)
        {
            strcpy(registroProcessos.terminalSTATUS, "Falhou");
        }
    }


}

void executa_menu(int opcao)
{
    char url[128];  /*url para abrir no navegador*/


    switch(opcao)
    {
    case 1:
        printf("Digite a URL: \n");
        scanf("%s", &url);
        cria_processo_programa("/usr/bin/firefox", "firefox", url);
        break;
    case 2:
        cria_processo_programa("/usr/bin/gedit", "gedit", NULL);
        break;
    case 3:
        cria_processo_programa("/usr/bin/xterm", "xterm", NULL);
        break;
    case 4:

        printf("Qual das aplicacoes voce deseja finalizar (1, 2 ou 3)? \n");

        scanf("%d", &opcaokill);

        if(opcaokill == 1)
        {
            finaliza_processo(registroProcessos.webPID,registroProcessos.webSTATUS, opcaokill);
        }

        else if(opcaokill == 2)
        {
            finaliza_processo(registroProcessos.editorPID,registroProcessos.editorSTATUS, opcaokill);
        }

        else if(opcaokill == 3)
        {
            finaliza_processo(registroProcessos.terminalPID,registroProcessos.terminalSTATUS, opcaokill);
        }
        break;

    case 5:
        printf("Programa finalizado\n");
        break;
    }
}

int main()
{

    sinais();

    do
    {
        //renicia a tela a cada 5 segundos
        if(alarm(5) < 0 )
        {
            perror("Erro - alarm");
        }

        //Menu principal
        menuAplicacao();

        printf("Digite uma opção: ");

        scanf("%d",&opcao_escolhida);


        executa_menu(opcao_escolhida);

    }
    while(opcao_escolhida != 5);

    sleep(1);
    return(0);

}