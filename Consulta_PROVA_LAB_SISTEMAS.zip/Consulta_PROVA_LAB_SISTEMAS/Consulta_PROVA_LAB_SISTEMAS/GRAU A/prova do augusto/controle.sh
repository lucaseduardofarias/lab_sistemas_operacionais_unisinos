#!/bin/bash

while [ 1 ] ; do
	clear
	echo "*********************************"
	echo "***********Controle**************"
	echo "*********************************"
	echo "1 - Calendario"
	echo "2 - Texto"
	echo "3 - Contabilidade"
	echo "4 - Vendas"
	echo "5 - Sair"
	echo "********************************* \n"
	echo "Digite a opção desejada: __ \n"
	read opcao
	echo "*********************************"
	echo "*********************************"
	
	case "$opcao" in
		1 )
			cal
			echo "\n"
			date
		;;
		
		2 )
			echo "Digite um texto: "
			read palavra
			gcc -Wall texto.c -o texto
			./texto $palavra
		;;
		
		3 )
			gcc -Wall contabilidade.c -o contabilidade
			./contabilidade
		;;
		
		4 )
			gcc -Wall vendas.c -o vendas
			./vendas
		;;
		
		5 )
			echo "Obrigado por utilizar o sistema!"
			exit 0
		;;
	esac
	sleep 5
done