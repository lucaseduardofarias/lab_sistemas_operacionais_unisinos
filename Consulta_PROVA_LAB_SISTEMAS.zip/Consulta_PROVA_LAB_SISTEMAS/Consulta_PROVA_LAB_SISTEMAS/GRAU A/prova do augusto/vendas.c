#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<signal.h>
#include<sys/types.h>
/*Feito por Augusto Lumi da Silveira*/
int _qtd;
float _preco;
float total(){
	return _qtd * _preco;
}
float contribuicao(){
	return total() * 0.5;	
}
float icms(){
	return (total() + contribuicao()) * 0.17;	
}
float valorDeVenda(){
	return (total() + contribuicao() + icms());	
}
int main(){

	printf("Digite a quantidade: ");
	scanf("%d", &_qtd);
	printf("Digite o preço: ");
	scanf("%f", &_preco);

	printf("O valor de custo total do produto é R$ %5.2f (%d X R$ %5.2f)\n", total(), _qtd, _preco);
	printf("O valor de margem de contribuiçao é R$ %5.2f \n", contribuicao());
	printf("O valor de ICMS para o produto é: R$ %5.2f \n", icms());	   
	printf("O valor de venda do produto é R$ %5.2f \n", valorDeVenda());
		   
}