#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
/*Feito por Augusto Lumi da Silveira*/
char* _palavra = "";

int contarVogais(){
	int i, contador = 0;
	for (i=0; _palavra[i]!='\0';i++){
		if (_palavra[i] == 'a' || _palavra[i] == 'e' || _palavra[i] == 'i' || _palavra[i] == 'o' || _palavra[i] == 'u')
			contador++;
	}
	return contador;
}

int contarEspacos(){
	int i, contador = 0;
	for (i=0; _palavra[i]!='\0';i++){
		if (_palavra[i] == ' ')
			contador++;
	}
	return contador;
}

int main(int agrc, char *argv[]){
	_palavra = argv[1];
	int espacos = contarEspacos();
	int vogais = contarVogais();
	int consoantes = (strlen(_palavra) - vogais) - espacos;
	
	printf("A quantidade de palavras é %d \n", (espacos + 1));
	printf("A quantidade de vogais é %d \n", vogais);
	printf("A quantidade de consoantes é %d \n", consoantes);
}