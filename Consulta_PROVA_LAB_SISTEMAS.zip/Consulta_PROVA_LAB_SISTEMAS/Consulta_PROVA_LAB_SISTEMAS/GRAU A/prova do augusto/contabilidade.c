#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/wait.h>

/*Feito por Augusto Lumi da Silveira*/
void tratador(int signum){
	switch(signum){
		case SIGUSR1: printf("Sinal recebido. Aguardar a conclusão do processo filho!"); break;
		case SIGUSR2: printf("Sinal recebido. Ainda em processamento.."); break;
		case SIGINT: printf("Sinal recebido. Obrigado por utilizar contabilidade"); exit(-1);
		case SIGTERM: printf("Sinal recebido. Obrigado por utilizar contabilidade"); exit(-1);
	}
}
int main(){
	sigset_t mask;
	
	sigaddset(&mask, SIGUSR1);
	sigaddset(&mask, SIGUSR2);
	
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = &tratador;
	
	if(sigaction(SIGUSR1, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR1");
		exit(-1);
	}
	if(sigaction(SIGUSR2, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR2");
		exit(-1);
	}
	if(sigaction(SIGINT, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGINT");
		exit(-1);
	}
	if(sigaction(SIGTERM, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGTERM");
		exit(-1);
	}
	
	int status;
	int salarioAnual, salarioMedio;
	printf("Informe seu salario anual: ");
	scanf("%d", &salarioAnual);
	
	while(salarioAnual < 0 || salarioAnual > 120000){
		printf("Valor informado invalido, por favor informe um valor valido: ");
		scanf("%d", &salarioAnual);
	}
	
	salarioMedio = salarioAnual / 12;
	
	if(salarioMedio < 3000){
		pid_t p = fork();
		if( p == 0){
			printf("Filho: meu PID = %d, PPID = %d \n", getpid(), getppid());
			execlp("/usr/home/simplificado", "simplificado" NULL);	
		}else{
			p = wait(&status);
		}
		
	} else{
		pid_t p = fork();
		if( p == 0){
			printf("Filho: meu PID = %d, PPID = %d \n", getpid(), getppid());
			execl("/usr/bin/firefox", "/usr/bin/firefox", "www.receita.fazenda.gov.br", (char*)NULL);
		}else{
			p = wait(&status);
		}
	}
	
	
}