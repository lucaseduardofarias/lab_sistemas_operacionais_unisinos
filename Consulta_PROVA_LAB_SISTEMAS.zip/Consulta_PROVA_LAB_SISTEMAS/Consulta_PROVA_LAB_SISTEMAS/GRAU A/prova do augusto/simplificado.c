#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<signal.h>
#include<sys/types.h>
/*Feito por Augusto Lumi da Silveira*/
int main(){
	printf("Isento de imposto de renda\n");
	execl("/bin/date", "date", NULL);
	exit(1);
}