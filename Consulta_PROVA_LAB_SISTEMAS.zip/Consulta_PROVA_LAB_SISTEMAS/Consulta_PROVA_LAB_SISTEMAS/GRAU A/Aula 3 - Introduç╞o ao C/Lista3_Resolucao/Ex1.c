#include<stdio.h>
int main(){

	printf("Olá Mundo \n %.3f \n", 3.141581);
	return(0);
}
