//Artur Eduardo Girelli
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>

int main(int argc, char *argv[])
{
	if (argc > 0){
		int qtdPalavras = argc-1;
		int qtdVogais = 0;
		int qtdConsoantes = 0;
		
		int i, j = 0;
		int letra = 0;
		for(i = 1; i < argc; i++){
			for(j = 0; j < strlen(argv[i]); j++){
				letra = argv[i][j];
				if(letra == 'A' || letra == 'a' || letra == 'E' || letra == 'e' || letra == 'I' || letra == 'i'|| letra == 'O' || letra == 'o' || letra == 'U' || letra == 'u'){
					qtdVogais++;
				}else{
					qtdConsoantes++;
				}
			}
		}
		
		printf("Existem %d palavras\n",qtdPalavras);
		printf("Existem %d vogais\n",qtdVogais);
		printf("Existem %d consoantes\n",qtdConsoantes);
	}
	else{
		printf("Voce nao informou o texto!\n");	
		exit(-1);
	}

	return 0;
}
