#Artur Eduardo Girelli
#!/bin/bash

while [ 1 ]; do
	clear
	echo "***************************"
	echo "******** CONTROLE *********"
	echo "***************************"
	echo "1 - Calendario"
	echo "2 - Texto"
	echo "3 - Contabilidade"
	echo "4 - Vendas"
	echo "5 - Sair"
	echo "***************************"
	echo "Digite a opçao desejadada: "
	read opcao
	echo "***************************"
	
	if [ $opcao = 1 ]; then
		cal
		date
	elif [ $opcao = 2 ]; then
		echo "Informe o texto: "
		read txt
		gcc -Wall texto.c -o texto
		./texto $txt
	elif [ $opcao = 3 ]; then
		gcc -Wall contabilidade.c -o contabilidade
		gcc -Wall simplificado.c -o simplificado
		./contabilidade
	elif [ $opcao = 4 ]; then
		gcc -Wall vendas.c -o vendas
		./vendas
	elif [ $opcao = 5 ]; then
		echo "Obrigado por utilizar o sistema de controle!"
		exit 0
	fi
	sleep 3
done