//Artur Eduardo Girelli
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int qtd;
float precoUnitario;

float calcularCustoTotal(){
	float custoTotal = qtd * precoUnitario;
	return custoTotal;
}

float calcularMargemDeContribuicao(){
	float margem = calcularCustoTotal() * 0.5;
	return margem;
}

float calcularICMS(){
	float icms = ((calcularCustoTotal()+calcularMargemDeContribuicao())*0.17);
	return icms;
}

float calcularValorDeVenda(){
	float valorDeVenda = calcularCustoTotal()+calcularMargemDeContribuicao()+calcularICMS();
	return valorDeVenda;
}

int main(){
	printf("Informe a quantidade: \n");
	scanf("%d",&qtd);
	
	while(qtd <= 0){
		printf("Valor invalido. Informe a quantidade: \n");
		scanf("%d",&qtd);
	}
	
	printf("Informe o valor unitario: \n");
	scanf("%f",&precoUnitario);
	
	while(precoUnitario <= 0){
		printf("Valor invalido. Informe o preço unitario: \n");
		scanf("%f",&precoUnitario);
	}
	
	printf("O custo total do produto e R$ %5.2f (%d x R$ %5.2f)\n",calcularCustoTotal(),qtd,precoUnitario);
	printf("O valor de margem de contribuicao e R$ %5.2f\n",calcularMargemDeContribuicao());
	printf("O valor do ICMS do produto e R$ %5.2f\n",calcularICMS());
	printf("O valor de venda do produto e R$ %5.2f\n",calcularValorDeVenda());
	
	return 0;
}