#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <time.h>

const char* nomefila = "/jogomemoria";

typedef struct Mensagem {
	int jogador;
	int l1;
	int c1;
	int l2;
	int c2;
} TMensagem;

int main(int argc, char* argv[]) {
    srand(time(NULL));   // Initialization, should only be called once.

	mqd_t queue;
	TMensagem jogada;
	int jogador = 0, sair = 1;
	int l1 = 0, c1 = 0, l2 = 0, c2 = 0;

	queue = mq_open(nomefila, O_WRONLY | O_CREAT, 0777 , NULL);
	if (queue == (mqd_t) -1) {
		perror("Erro na abertura da fila!");
		exit(2);
	}

	while(sair==1){
		printf("Digite o id do jogador, 1 ou 2: ");
		scanf("%d",&jogador);

		if (jogador == 1){
            printf("Digite a posição da linha1: ");
            scanf("%d",&l1);
            printf("Digite a posição da coluna1: ");
            scanf("%d",&c1);
            printf("Digite a posição da linha2: ");
            scanf("%d",&l2);
            printf("Digite a posição da coluna2: ");
            scanf("%d",&c2);
		}else{
            l1 = rand() % 4;
            c1 = rand() % 4;
            l2 = rand() % 4;
            c2 = rand() % 4;
		}

		//Monta mensagem
		jogada.jogador = jogador;
		jogada.l1 = l1;
		jogada.c1 = c1;
		jogada.l2 = l2;
		jogada.c2 = c2;

		if (mq_send(queue, (const char*) &jogada, sizeof(TMensagem), 0) != 0) {
			perror("Erro no envio da mensagem!");
		}

		printf("Mensagem enviada!\n");

		printf("Deseja continuar jogando? Digite 1 para CONTINUAR e 0 para NÃO ");
		scanf("%d",&sair);
	}

	mq_close(queue);

	printf("Programa finalizado!\n");
	exit(EXIT_SUCCESS);
}
