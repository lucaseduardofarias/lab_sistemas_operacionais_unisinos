#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mqueue.h>

#define linhaPrincipal 4
#define colunaPrincipal 4
#define FILE_MAX_LENGTH 512


const char* nomefila = "/jogomemoria";
char nomearq[256] = "jogo.txt";

typedef struct Mensagem {
	int jogador;
	int l1;
	int c1;
	int l2;
	int c2;
} TMensagem;

char times[linhaPrincipal][colunaPrincipal][50];
int acertos[linhaPrincipal][colunaPrincipal];
int controlaJogador = 1;
int controlaFim = 0;
int pontuacaoJogador1 = 0;
int pontuacaoJogador2 = 0;


void printMensagem(TMensagem* msg);
ssize_t get_msg_buffer_size(mqd_t queue);
void tratador(int signum);
int attPontuacao(int jogador, int lin1, int col1, int lin2, int col2);
void exibeVencedor();
void exibirTimes();
int verificaJogada(int lin1, int col1, int lin2, int col2);
void inserirTimes(int fd);
int controleDoJogador(int jogador);
int finaliza();


//printa msg
void printMensagem(TMensagem* msg) {
	printf("Jogador: %d - [%d][%d] [%d][%d]", msg->jogador, msg->l1, msg->c1, msg->l2, msg->c2);
}

ssize_t get_msg_buffer_size(mqd_t queue) {
	struct mq_attr attr;

	/* Determine max. msg size; allocate buffer to receive msg */
	if (mq_getattr(queue, &attr) != -1) {
		return attr.mq_msgsize;
	}

	perror("Erro na alocacao de buffer!");
	exit(3);
}

void tratador(int signum){
    switch(signum){
	case SIGUSR2:
	    printf("O jogo foi cancelado por conta da notificação da CBF! Obrigado\n");
	    exit(0);
            break;
    }
}

int attPontuacao(int jogador, int lin1, int col1, int lin2, int col2){	//Valida as pos são iguais
    printf("\nJOGADA: [%d][%d]: %s \t [%d][%d]: %s \n",lin1,col1,times[lin1][col1],lin2,col2,times[lin2][col2]);
    if (strcmp (times[lin1][col1], times[lin2][col2]) == 0) {
        acertos[lin1][col1] = 1;
        acertos[lin2][col2] = 1;

        if (jogador == 1)
            pontuacaoJogador1++;
        else
            pontuacaoJogador2++;

        return -1;
    }

    if (controlaJogador == 1){
        controlaJogador = 2;
    }else{
        controlaJogador = 1;
    }


    return 0;
}

void exibeVencedor(){
    if (pontuacaoJogador1 > pontuacaoJogador2){
        printf("Jogador 1 ganhou\n");
    }else if (pontuacaoJogador2 > pontuacaoJogador1){
        printf("Jogador 2 ganhou\n");
    }else{
        printf("Empate!\n");
    }
}

void exibirTimes(){//att jogo
    int contAcertos = 0;

    printf("\n--------- TABULEIRO ---------\n");
    for(int i=0;i<linhaPrincipal;i++){
        for(int j=0;j<colunaPrincipal;j++){
            if (acertos[i][j] == 1){
                printf("%s\t",times[i][j]);
                contAcertos++;
            }
            else{
               printf("X\t");
            }
        }
        printf("\n");
    }
    if (contAcertos == 16)
        controlaFim = -1;	//att o contador acertos

    printf("\n--------- PONTUAÇÕES ---------\n Jogador 1: %d \n Jogador 2: %d\n\n",pontuacaoJogador1,pontuacaoJogador2);
}





int verificaJogada(int lin1, int col1, int lin2, int col2){
    if ((lin1<linhaPrincipal && lin1>=0) && (lin2<linhaPrincipal && lin2>=0) && (col1<colunaPrincipal && col1>=0) && (col2<colunaPrincipal && col2>=0) && (acertos[lin1][col1] == 0) && (acertos[lin2][col2] == 0) && ((lin1 != lin2) || (col1 != col2))) return -1;
    return 0;
}

void inserirTimes(int fd)
{
    char texto[FILE_MAX_LENGTH];
    char *palavraTime;
    const char split[2] = ";";
    int lin=0, col=0, pos = 0, controlador = 0;

    lseek(fd, 0, SEEK_SET);
    read(fd, texto, FILE_MAX_LENGTH);

    while (texto[pos] != '\0'){//verifica qnt de times
        if (texto[pos++]==';'){
            controlador++;
        }
    }
    if (controlador != (linhaPrincipal*colunaPrincipal)) {
        printf("\nArquivo inválido! O jogo deve conter %d times!\n",linhaPrincipal*colunaPrincipal);
        exit(0);
    }

    palavraTime = strtok(texto, split);

    while(palavraTime != NULL) {
      strcpy(times[lin][col],palavraTime);
      acertos[lin][col]=0;

      if (++col==colunaPrincipal){
        col=0;
        if (++lin==linhaPrincipal)
            break;
      }
      palavraTime = strtok(NULL, split);
    }
}

int controleDoJogador(int jogador){
    if (controlaJogador == jogador)
        return -1;
    return 0;
}



int finaliza(){
    return controlaFim;
}

int main()
{
    int fd;
    int l1 = 0, c1 =0, l2 = 0, c2 = 0, jogador = 1;
    TMensagem msgJogada;

    mqd_t queue;
    char* buffer = NULL;
    ssize_t tam_buffer;
    ssize_t nbytes;

    queue = mq_open(nomefila, O_RDONLY);
    if (queue == (mqd_t) -1) {
        perror("Erro na abertura da fila!");
        exit(2);
    }

    tam_buffer = get_msg_buffer_size(queue);
    buffer = calloc(tam_buffer, 1);

    fd = open(nomearq, O_RDONLY);

    if (fd == -1){//verifica se arquivo existe
        printf("\nO arquivo não existe.\n");
	return 99;
    }

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = &tratador;

    if(sigaction(SIGUSR2, &sa, NULL) != 0){
        perror("Falha ao instalar tratador de sinal SIGUSR1");
	return 0;
    }

    inserirTimes(fd);//Carrega os times para a matriz

    while(1){
        exibirTimes();

        if(finaliza()) {
            printf("\n----------- Jogo Terminou ------------n");
                exibeVencedor();
            break;
        }

        printf("\nAguardando a msg da jogada... \n");

        nbytes = mq_receive(queue, buffer, tam_buffer, NULL);
        if (nbytes == -1) {
            perror("receive");
            exit(4);
        }

        printMensagem((TMensagem*) buffer);

        msgJogada = *(TMensagem*) buffer;

        jogador = msgJogada.jogador;
        l1 = msgJogada.l1;
        c1 = msgJogada.c1;
        l2 = msgJogada.l2;
        c2 = msgJogada.c2;

        if(!controleDoJogador(jogador)){
            printf("\n\nVocê não inseriu um jogador válido\n");
        }else {
            if(!verificaJogada(l1,c1,l2,c2)){
                printf("\n\nJogada inválida realizada\n");
            }else if (attPontuacao(jogador, l1,c1,l2,c2)){
                printf("\n\nAcertou os times\n");
            }else{
                printf("\n\nErrou\n");
            }
        }
    }
    close(fd);

    mq_close(queue);

    return 0;
}

