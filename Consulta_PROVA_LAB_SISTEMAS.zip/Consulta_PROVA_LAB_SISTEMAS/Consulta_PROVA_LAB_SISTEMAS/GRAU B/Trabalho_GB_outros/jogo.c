//Artur Eduardo e Augusto Lumi - Turma 23

#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<signal.h>
#include<pthread.h>
#include<errno.h>
#include<fcntl.h>
#include<assert.h>
#include <time.h>
#include <semaphore.h>

void tratador(int signum);
void jogar(int jogador);
char* infoWrite(int status, char* nome);
void getData();
void limpaTabuleiro();
void printTabuleiro();
int checaJogada(int linha, int coluna, int jogador);
int checaLinha(int linha, int jogador);
int checaColuna(int coluna, int jogador);
int checaDiagonal(int jogador);
int checaEmpate();
int checaVitoria(int linha, int coluna, int jogador);
int checaFinal(int linha, int coluna, int jogador);
void* jogador1(void *arg);
void* jogador2(void *arg);

#define clear() printf("\033[H\033[J");

//Define dimensao padrao
char _tabuleiro[3][3];
char _nomeX[50], _nomeO[50];
int _contJogadas = 0;
int _fim = 0;
char escrever[180];
char _datahora[100];

sem_t tela_lock;

int main(){
	//tratamento de sinais
    struct sigaction sa;
	memset(&sa, 0, sizeof(sa));

	sa.sa_handler = &tratador;

	if(sigaction(SIGUSR1, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR1");
		exit(-1);
	}
	if(sigaction(SIGUSR2, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGUSR1");
		exit(-1);
	}
	if(sigaction(SIGCONT, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGCONT");
		exit(-1);
	}
	if(sigaction(SIGTERM, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGTERM");
		exit(-1);
	}
	if(sigaction(SIGINT, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGINT");
		exit(-1);
	}
	if(sigaction(SIGTSTP, &sa, NULL) != 0){
		perror("Falha ao instalar tratador de sinal SIGTSTP");
		exit(-1);
	}

	limpaTabuleiro();

    printf("Nome do jogador 'X':\n");
	scanf("%s", _nomeX);

	printf("Nome do jogador 'O':\n");
	scanf("%s", _nomeO);
	
	clear()
		
	printTabuleiro();

	pthread_t t[2];
	sem_init(&tela_lock, 0, 1);
	
	//cria e/ou limpa o arquivo
	open("LogDeJogadas.txt", O_CREAT | O_TRUNC, 0600);

	//lop ate o programa ser encerrado pelo jogar()
	while(1){
        //criando os jogadores
		pthread_create(&t[0], NULL, &jogador1, NULL);
		pthread_create(&t[1], NULL, &jogador2, NULL);
	}
}

//trata os sinais recebidos, so para se receber SIGTERM
void tratador(int signum){
    switch(signum){
		case SIGTERM:
			printf("Fim do jogo!\n");
			exit(1);
			break;
		default:
			printf("Sinal recebido: %d\n", signum);
			return;
    }
}

//inicia o jogador 1
void* jogador1(void *arg){
	//verifica o semaforo para ver se a outra thread ja terminou
    if (sem_wait(&tela_lock) != 0){
        exit(85);
    }
    printf("E a vez de %s (O)\n",_nomeO);
    jogar(1);
	sleep(1);
	//decremnta o semaforo
    if (sem_post(&tela_lock) != 0) {
        exit(85);
    }
    return NULL;
}

//inicia o jogador 1
void* jogador2(void *arg){
	//verifica o semaforo para ver se a outra thread ja terminou
	if (sem_wait(&tela_lock) != 0){
        exit(85);
	}
    printf("E a vez de %s (X)\n",_nomeX);
    jogar(2);
	sleep(1);
	//decremnta o semaforo
    if (sem_post(&tela_lock) != 0) {
        exit(85);
    }
    return NULL;
}

//realiza a jogada
void jogar(int jogador){
    int linha, coluna;
    printf("Informe a linha: \n");
    scanf("%d", &linha);
    printf("Informe a coluna: \n");
    scanf("%d", &coluna);
	
	escrever[0] = '\0';
	_datahora[0] = '\0';
	
    int jogada;
	//recebe o retorno do metodo que verifica se e valida e passa ao switch case
    jogada = checaJogada(linha-1, coluna-1, jogador);

    //open do log de jogadas
    int fd = open("LogDeJogadas.txt", O_CREAT | O_APPEND | O_RDWR, 0600);
    char* info;
	//incrementa o contador de jogadas
	_contJogadas++;
	//loop em quanto a condicao de fim (vitoria ou empate) nao for satisfeita
    while (_fim != 1){
        switch (jogada){
			//se a jogada for invalida
            case -1:
			//recebe o array de informacoes para escrever no arquivo
            if (jogador == 1){
                info = infoWrite(-1, _nomeO);
			}
            else{
                info = infoWrite(-1, _nomeX);
			}
			//escreve no arquivo
			write(fd, info, strlen(escrever));
			close(fd);
            printf("Jogada invalida\n");
            break;
			//se a jogada for valida	
            case 0:
				//atribui a matriz de acordo com a thread
				if (jogador == 1){
					_tabuleiro[linha-1][coluna-1] = 'O';
				}
				else{
					_tabuleiro[linha-1][coluna-1] = 'X';
				}
				printf("Jogada valida\n");
				sleep(2);
				printTabuleiro();
				//verifica se e uma condicao de termino
				int ehFinal = checaFinal(linha-1,coluna-1,jogador);
				//se a jogada for a jogada vencedora
				if(ehFinal == 1){
					printf("Jogada vencedora\n");
					sleep(2);
					if (jogador == 1){
						printf("Vitoria do jogador %s \n", _nomeO);
						info = infoWrite(1, _nomeO);
					}else {
						printf("Vitoria do jogador %s \n", _nomeX);
						info = infoWrite(1, _nomeX);
					}
					write(fd, info, strlen(escrever));
					close(fd);
					_fim = 1;
					sem_destroy(&tela_lock);
					exit(1);
				//se a jogada for a jogada de empate
				}else if(ehFinal == 2){
					printf("Jogada de empate\n");
					sleep(2);
					printf("Jogo terminado em empate\n");
					if (jogador == 1){
						info = infoWrite(2, _nomeO);
					}
					else{
						info = infoWrite(2, _nomeX);
					}
					write(fd, info, strlen(escrever));
					close(fd);
					_fim = 1;
					sem_destroy(&tela_lock);
					exit(2);
				}else{
					//se for apenas valido
					if (jogador == 1){
					info = infoWrite(0, _nomeO);
					}
					else{
						info = infoWrite(0, _nomeX);
					}
					write(fd, info, strlen(escrever));
					close(fd);
					return;
				}
            default:
				return;
		}

		//se a jogada for invalida entrara aqui
        printf("Jogada invalida, jogue novamente...\n");
        printf("Informe a linha: ");
        scanf("%d", &linha);
        printf("Informe a coluna: ");
        scanf("%d", &coluna);

        jogada = checaJogada(linha-1, coluna-1, jogador);
	}
}

char* infoWrite(int status, char* nome){	
	//datahora;nome;lance;status
  	getData();
	
	//escrever a data e hora
	strcat(escrever,_datahora);
	//escrever o nome do jogador
	strcat(escrever,nome);
	strcat(escrever,";");
	//escrever o lance do jogador
	char scont[5];
	sprintf(scont,"%d",_contJogadas);
	strcat(escrever,scont);
	strcat(escrever,";");
	//escrever o status
	switch(status){
		case -1:
			strcat(escrever,"Jogada invalida");
			break;
		case 0:
			strcat(escrever,"Jogada valida");
			break;
		case 1:
			strcat(escrever,"Jogada vencedora");
			break;
		case 2:
			strcat(escrever,"Jogada de empate");
			break;
		default:
			break;
	}
	strcat(escrever,"\n");
	
	return escrever;
}

//puxa todos os dados para data e hora
void getData(){
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    int ano = tm.tm_year;
	int mes = tm.tm_mon + 1;
	int dia = tm.tm_mday;
	int hora = tm.tm_hour;
	int min = tm.tm_min;
	
	char sano[5];
	sprintf(sano,"%d",(ano+1900));
	char smes[4];
	sprintf(smes,"%d",mes);
	char sdia[3];
	sprintf(sdia,"%d",dia);
	char shora[3];
	sprintf(shora,"%d",hora);
	char smin[3];
	sprintf(smin,"%d",min);
	
	strcat(_datahora,sdia);
	strcat(_datahora,"/");
	strcat(_datahora,smes);
	strcat(_datahora,"/");
	strcat(_datahora,sano);
	strcat(_datahora,";");
	strcat(_datahora,shora);
	strcat(_datahora,":");
	strcat(_datahora,smin);
	strcat(_datahora,";");
	
	return;
}

//limpa o tabuleiro
void limpaTabuleiro(){
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            _tabuleiro[i][j] = '.';
        }
    }

}

//da clear no terminal e printa o tabuleiro (matriz)
void printTabuleiro(){
    system("clear");
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if(j == 3 -1)
                printf("%c \n", _tabuleiro[i][j]);
            else
                printf("%c |", _tabuleiro[i][j]);
        }
    }
}

//verifica se a jogada e valida
int checaJogada(int linha, int coluna, int jogador){
    if(linha < 0 || linha >= 3)
        return -1;
    if(coluna < 0 || coluna >= 3)
        return -1;
    if(_tabuleiro[linha][coluna] != '.')
        return -1;
    return 0;
}

//verifica se e o fim chamando os metodos
int checaFinal(int linha,int coluna,int jogador){
	if(checaVitoria(linha,coluna,jogador) == 1){
        return 1;
	}
    if(checaEmpate() == 1){
        return 2;
	}
	return 0;
}

//chama os metodos secundarios e soma caso haja retorno, se for > 0 a vitoria aconteceu
int checaVitoria(int linha, int coluna, int jogador){
    int vitoria = 0;
    vitoria += checaLinha(linha, jogador);
    vitoria += checaColuna(coluna, jogador);
    vitoria += checaDiagonal(jogador);
    if(vitoria > 0)
        return 1;
	else
		return 0;
}

//checa se a linha esta preenchida por um caractere
int checaLinha(int linha, int jogador){
    int soma = 0;
	char j;
	if(jogador == 1)
		j = 'O';
	else
		j = 'X';
    for(int i = 0; i < 3;i++)
        if(_tabuleiro[linha][i] == j)
            soma++;
    if(soma == 3)
        return 1;
	else
    	return 0;
}

//checa se a coluna esta preenchida por um caractere
int checaColuna(int coluna, int jogador){
    int soma = 0;
		char j;
	if(jogador == 1)
		j = 'O';
	else
		j = 'X';
    for(int i = 0; i < 3;i++)
        if(_tabuleiro[i][coluna] == j)
            soma++;
    if(soma == 3)
        return 1;
    else
		return 0;
}

//checa a diagonal primaria e secundaria estao preenchidas por um caractere
int checaDiagonal(int jogador){
    int somaDP = 0;
    int somaDS = 0;
	char j;
	if(jogador == 1)
		j = 'O';
	else
		j = 'X';
    for(int i = 0; i < 3;i++){
        if(_tabuleiro[i][i] == j)
            somaDP++;
        if(_tabuleiro[i][3 - i - 1] == j)
            somaDS++;
    }
    if(somaDP >= 3 || somaDS >= 3)
        return 1;
    else
		return 0;
}

//se nao houver nenhum ponto e um empate (retorna 1)
int checaEmpate(){
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            if(_tabuleiro[i][j] == '.'){
                return 0;
			}
        }
    }
	return 1;
}
