#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>

int main(){

	char texto[100];

	printf("Digite o texto: ");
	fgets(texto, 100, stdin);
	getchar();
	printf("%s", texto);

	return(0);
}
