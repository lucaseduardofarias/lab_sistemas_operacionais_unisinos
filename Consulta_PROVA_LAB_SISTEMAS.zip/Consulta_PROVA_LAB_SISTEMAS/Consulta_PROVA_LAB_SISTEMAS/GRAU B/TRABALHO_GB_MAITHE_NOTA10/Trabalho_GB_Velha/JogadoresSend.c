#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <sys/types.h>
#include <sys/wait.h>

//Nome da fila
const char* NOME_FILA = "/filaJogada";
//variaiaveis globais
int controlaWhile = 0;

//Estrutura de dados para a mensagem
typedef struct Mensagem
{
    int X;
    int Y;
    pid_t pidJogador;
} TMensagem;

TMensagem m;
int controlePermissaoJogada = 0;
void jogada(void);
mqd_t queue;

void tratador(int signum)
{
    switch(signum)
    {
    case SIGUSR1:
        controlaWhile = 1;
        system("clear");
        printf("\nÉ sua vez de jogar, jogador (X).\n");
        sleep(2);
        controlePermissaoJogada = 0;
        break;
    case SIGUSR2:
        system("clear");
        printf("\nPosição invalida, jogue novamente\n");
        controlePermissaoJogada = 0;
        controlaWhile = 1;
        break;
    case SIGCONT:
        system("clear");
        printf("\nEssa posição já esta ocupada, jogue novamente\n");
        controlePermissaoJogada = 0;
        controlaWhile = 1;
        break;
    case SIGTERM:
        printf("\nServidor solicitou que os processos Jogadores sejam finalizado.\n");
        exit(EXIT_SUCCESS);
        break;
    case SIGINT:
        controlaWhile = 1;
        system("clear");
        printf("\nÉ sua vez de jogar, jogador (O).\n");
        sleep(2);
        controlePermissaoJogada = 0;
        break;
    case SIGTSTP:
        printf("Recebido sinal SIGTSTP (%d)\n", signum);
        break;
    case SIGQUIT:
        system("clear");
        printf("Jogo finalizado, confira no display do servidor o ganhador\n");
        exit(EXIT_SUCCESS);
        break;
    case SIGHUP:
        controlePermissaoJogada = 1;
        system("clear");
        printf("\nEspere por sua vez de jogar\n");
        break;
      }
}

void sinais()
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));

    sa.sa_handler = &tratador;



    if(sigaction(SIGUSR1, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGUSR1");
        exit(-1);
    }
    if(sigaction(SIGUSR2, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGUSR1");
        exit(-1);
    }
    if(sigaction(SIGCONT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGCONT");
        exit(-1);
    }
    if(sigaction(SIGTERM, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGTERM");
        exit(-1);
    }
    if(sigaction(SIGINT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGINT");
        exit(-1);
    }
    if(sigaction(SIGTSTP, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGTSTP");
        exit(-1);
    }
    if(sigaction(SIGQUIT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGQUIT");
        exit(-1);
    }

    if(sigaction(SIGHUP, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGHUP");
        exit(-1);
    }

}

void jogada(void)
{
    printf("Digite a cordernada para X:");
    scanf("%d", &m.X);

    printf("Digite a cordernada para Y:");
    scanf("%d", &m.Y);
    m.pidJogador = getpid();
}
void whileControler()
{

    while(controlaWhile == 0)
    {

        if(controlePermissaoJogada == 0)
        {


            //Obter descritor (mq_open+O_WRONLY+O_CREAT)
            queue = mq_open(NOME_FILA, O_WRONLY | O_CREAT, 0770, NULL);
            if (queue == (mqd_t) -1)
            {

                perror("mq_open");
                exit(2);
            }
            if(controlaWhile == 1)
                break;

            printf("Digite a cordernada para X:");
            scanf("%d", &m.X);

            if(controlaWhile == 1)
                break;

            printf("Digite a cordernada para Y:");
            scanf("%d", &m.Y);
            m.pidJogador = getpid();


            //Enviar (mq_send)
            if (mq_send(queue, (const char*) &m, sizeof(TMensagem), 29) != 0)
            {
                perror("send #29");
            }

            //Liberar descritor (mq_close)
            mq_close(queue);

            printf("Mensagem enviada!\n");
            m.X = 0;
            m.Y = 0;
            controlePermissaoJogada = 1;
            system("clear");
        }
    }

    controlaWhile = 0;
    whileControler();

}

int main()
{
    sinais();
    whileControler();
    exit(EXIT_SUCCESS);

}
