#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <fcntl.h>
#include <time.h>



//Nome da fila
const char *NOME_FILA = "/filaJogada";
//Declarações das variaveis utilizadas.
char tela[3][3];
int i, j, x, y, _fim=1, pl, velha=0;
char _nomeX[50], _nomeO[50];
pid_t pid1;
pid_t pid2;
int jogar1Check = 1;
char escrever[180];
char _datahora[100];
char* info;
int fd;

//Estrutura de dados para a mensagem
typedef struct Mensagem
{
    int X;
    int Y;
    pid_t pidJogador;
} TMensagem;


//Declarações das funções
ssize_t get_msg_buffer_size(mqd_t queue);
void displayTabuleiro(void);
void verificaGanhador(int pl);
void play1();
void play2();
void limpaTabuleiro(void);
void exibeGanhador(char* nome);
void sinais();
void tratador(int signum);

void tratador(int signum)
{
    switch(signum)
    {
    case SIGUSR1:
        printf("Recebido sinal SIGUSR1 (%d)\n", signum);
        break;
    case SIGUSR2:
        printf("Recebido sinal SIGUSR2 (%d)\n", signum);
        break;
    case SIGCONT:
        printf("Recebido sinal SIGCONT (%d)\n", signum);
        break;
    case SIGTERM:
        printf("Recebido sinal SIGTERM (%d)\n", signum);
        break;
    case SIGINT:
        system("clear");
        printf("\nO programa será finalizado devido a utilização de sinal: SIGINT\n");
        char command1[128];
        snprintf(command1, sizeof(command1), "kill -s 15 %d", pid1);
        system(command1);
        char command2[128];
        snprintf(command2, sizeof(command2), "kill -s 15 %d", pid2);
        system(command2);

        exit(EXIT_SUCCESS);
        break;
    case SIGTSTP:
        printf("Recebido sinal SIGTSTP (%d)\n", signum);
        break;
    case SIGQUIT:
        printf("Recebido sinal SIGQUIT (%d)\n", signum);
        break;
    case SIGKILL:
        printf("Recebido sinal SIGKILL (%d)\n", signum);
        break;
    }
}

void sinais()
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));

    sa.sa_handler = &tratador;



    if(sigaction(SIGUSR1, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGUSR1");
        exit(-1);
    }
    if(sigaction(SIGUSR2, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGUSR1");
        exit(-1);
    }
    if(sigaction(SIGCONT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGCONT");
        exit(-1);
    }
    if(sigaction(SIGTERM, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGTERM");
        exit(-1);
    }
    if(sigaction(SIGINT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGINT");
        exit(-1);
    }
    if(sigaction(SIGTSTP, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGTSTP");
        exit(-1);
    }
    if(sigaction(SIGQUIT, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGQUIT");
        exit(-1);
    }

    if(sigaction(SIGHUP, &sa, NULL) != 0)
    {
        perror("Falha ao instalar tratador de sinal SIGHUP");
        exit(-1);
    }


}




//puxa todos os dados para data e hora
void getData(){
  time_t t = time(NULL);
  struct tm tm = *localtime(&t);
  int ano = tm.tm_year;
	int mes = tm.tm_mon + 1;
	int dia = tm.tm_mday;
	int hora = tm.tm_hour;
	int min = tm.tm_min;

	char sano[5];
	sprintf(sano,"%d",(ano+1900));
	char smes[4];
	sprintf(smes,"%d",mes);
	char sdia[3];
	sprintf(sdia,"%d",dia);
	char shora[3];
	sprintf(shora,"%d",hora);
	char smin[3];
	sprintf(smin,"%d",min);

	strcat(_datahora,sano);
	strcat(_datahora,"/");
	strcat(_datahora,smes);
	strcat(_datahora,"/");
    strcat(_datahora,sdia);
	strcat(_datahora,";");
	strcat(_datahora,shora);
	strcat(_datahora,":");
	strcat(_datahora,smin);
	strcat(_datahora,";");

	return;
}

char* infoWrite(int status, char* nome){
	//datahora;nome;lance;status
  	getData();

	//escrever a data e hora
	strcat(escrever,_datahora);
	//escrever o nome do jogador
	strcat(escrever,nome);
	strcat(escrever,";");
	//escrever o lance do jogador
	char scont[5];
	sprintf(scont,"%d %d" ,x,y);
	strcat(escrever,scont);
	strcat(escrever,";");
	//escrever o status
	switch(status){
		case -1:
			strcat(escrever,"Jogada invalida");
			break;
		case 0:
			strcat(escrever,"Jogada valida");
			break;
		case 1:
			strcat(escrever,"Jogada vencedora");
			break;
		case 2:
			strcat(escrever,"Jogada de empate");
			break;
		default:
			break;
	}
	strcat(escrever,"\n");

	return escrever;
}

void displayTabuleiro(void)
{

    system("clear");
    printf("\n\n");
    printf("   1   2   3   Y\n");
    printf(" 1 %c | %c | %c \n",tela[0][0],tela[0][1],tela[0][2]);
    printf("  ---|---|--- \n ");
    printf("2 %c | %c | %c \n",tela[1][0],tela[1][1],tela[1][2]);
    printf("  ---|---|--- \n ");
    printf("3 %c | %c | %c \n",tela[2][0],tela[2][1],tela[2][2]);
    printf("X\n");
}

int checaJogada(int linha, int coluna)
{
    if(linha < 0 || linha >= 3)
        return -1;
    if(coluna < 0 || coluna >= 3)
        return -1;
    if(tela[linha][coluna] != ' ')
        return -2;
    return 0;
}

void verificaGanhador(int pl)
{

    /*-------------VERIFICA NA HORIZONTAL--------*/
    if(x==0)
    {
        if((tela[0][0]==tela[0][1]) && (tela[0][1]==tela[0][2]))
        {
            displayTabuleiro();
		if (pl==1){
            		exibeGanhador(_nomeX);
		}else if (pl==2){
			exibeGanhador(_nomeO);
		}
            _fim=0;
        }
    }

    if(x==1)
    {
        if((tela[1][0]==tela[1][1]) && (tela[1][1]==tela[1][2]))
        {
            displayTabuleiro();
            if (pl==1){
            		exibeGanhador(_nomeX);
		}else if (pl==2){
			exibeGanhador(_nomeO);
		}
            _fim=0;
        }
    }

    if(x==2)
    {
        if((tela[2][0]==tela[2][1]) && (tela[2][1]==tela[2][2]))
        {
            displayTabuleiro();
           if (pl==1){
            		exibeGanhador(_nomeX);
		}else if (pl==2){
			exibeGanhador(_nomeO);
		}
            _fim=0;
        }
    }

    /*----------VERIFICA NA VERTICAL--------*/

    if(y==0)
    {
        if((tela[0][0]==tela[1][0]) && (tela[1][0]==tela[2][0]))
        {
            displayTabuleiro();
       if (pl==1){
            		exibeGanhador(_nomeX);
		}else if (pl==2){
			exibeGanhador(_nomeO);
		}
            _fim=0;
        }
    }

    if(y==1)
    {
        if((tela[0][1]==tela[1][1]) && (tela[1][1]==tela[2][1]))
        {
            displayTabuleiro();
           if (pl==1){
            		exibeGanhador(_nomeX);
		}else if (pl==2){
			exibeGanhador(_nomeO);
		}
            _fim=0;
        }
    }

    if(y==2)
        if((tela[0][2]==tela[1][2]) && (tela[1][2]==tela[2][2]))
        {
            displayTabuleiro();
         if (pl==1){
            		exibeGanhador(_nomeX);
		}else if (pl==2){
			exibeGanhador(_nomeO);
		}
            _fim=0;
        }

    if(((x==0)&&(y==0))||((x==1)&&(y==1))||((x==2)&&(y==2)))
    {
        if((tela[0][0]==tela[1][1]) && (tela[0][0]==tela[2][2]))
        {
            displayTabuleiro();
	   if (pl==1){
	    		exibeGanhador(_nomeX);
		}else if (pl==2){
			exibeGanhador(_nomeO);
		}
            _fim=0;
        }
    }


    if(((x==0)&&(y==2))||((x==1)&&(y==1))||((x==2)&&(y==0)))
    {
        if((tela[0][2]==tela[1][1]) && (tela[0][2]==tela[2][0]))
        {
            displayTabuleiro();
		if (pl==1){
		    		exibeGanhador(_nomeX);
			}else if (pl==2){
				exibeGanhador(_nomeO);
			}
            _fim=0;
        }
    }
}

void exibeGanhador(char* nome)
{
	escrever[0] = '\0';
	_datahora[0] = '\0';

    printf("\t JOGADOR   %s  GANHOU  \n",nome);
    char command1[128];
    snprintf(command1, sizeof(command1), "kill -s 3 %d", pid1);
    system(command1);
    char command2[128];
    snprintf(command2, sizeof(command2), "kill -s 3 %d", pid2);
    system(command2);
    info = infoWrite(1, nome);
    write(fd, info, strlen(escrever));
    close(fd);
}



void limpaTabuleiro(void)
{
    for(i=0; i<3; i++)
        for(j=0; j<3; j++)
            tela[i][j]=' ';
}

ssize_t get_msg_buffer_size(mqd_t queue)
{
    struct mq_attr attr;

    /*Determina max. msg size; allocate buffer to receive msg */
    if (mq_getattr(queue, &attr) != -1)
    {
        return attr.mq_msgsize;
    }

    perror("aloca_msg_buffer");
    exit(3);
}

void play1()
{


    displayTabuleiro();
    mqd_t queue;
    char* buffer = NULL;
    ssize_t tam_buffer;
    ssize_t nbytes;

    escrever[0] = '\0';
    _datahora[0] = '\0';



    queue = mq_open(NOME_FILA, O_RDONLY);
    if (queue == (mqd_t) -1)
    {
        perror("mq_open");
        exit(2);
    }


    tam_buffer = get_msg_buffer_size(queue);
    buffer = calloc(tam_buffer, 1);


    nbytes = mq_receive(queue, buffer, tam_buffer, NULL);
    if (nbytes == -1)
    {
        perror("receive");
        exit(4);
    }
    mq_close(queue);


    TMensagem* m =   (TMensagem*) buffer;

    if(pid1 == 0)
    {
        pid1 = m->pidJogador;
    }
    else if(pid2 == 0)
    {
        pid2 = m->pidJogador;
    }
    x = m->X;
    y = m->Y;

    pl=1;
    x--;
    y--;


}

void play2()
{

    displayTabuleiro();

    mqd_t queue;
    char* buffer = NULL;
    ssize_t tam_buffer;
    ssize_t nbytes;

    escrever[0] = '\0';
    _datahora[0] = '\0';



    queue = mq_open(NOME_FILA, O_RDONLY);
    if (queue == (mqd_t) -1)
    {
        perror("mq_open");
        exit(2);
    }


    tam_buffer = get_msg_buffer_size(queue);
    buffer = calloc(tam_buffer, 1);


    nbytes = mq_receive(queue, buffer, tam_buffer, NULL);
    if (nbytes == -1)
    {
        perror("receive");
        exit(4);
    }
    mq_close(queue);

    TMensagem* m =   (TMensagem*) buffer;
    if(pid1 == 0)
    {
        pid1 = m->pidJogador;
    }
    else if(pid2 == 0)
    {
        pid2 = m->pidJogador;
    }
    x = m->X;
    y = m->Y;

    pl=2;
    x--;
    y--;

}


int main(void)
{
    sinais();
    mq_unlink(NOME_FILA);
    limpaTabuleiro();
    int checkValidacao;
    printf("Nome do jogador 'X':\n");
    scanf("%s", _nomeX);

    printf("Nome do jogador 'O':\n");
    scanf("%s", _nomeO);



    displayTabuleiro();

    fd = open("LogDeJogadas.txt", O_CREAT | O_APPEND | O_RDWR, 0600);




    while(_fim!=0)
    {

        if(jogar1Check == 1)
        {

            if(_fim!=0)
            {

                printf("Jogador %s é sua vez",_nomeX);

                play1();
                checkValidacao = checaJogada(x,y);
                if(tela[x][y]==' ')
                {
                    tela[x][y]='X';
                    system("clear");
                    velha++;
                    info = infoWrite(0, _nomeX);
                    verificaGanhador(pl);

                }
                else
                {

                    if(checkValidacao  == -1)
                    {
                        printf("\nPosição invalida!!\n");
                        sleep(4);
                        system("clear");

                        char command[128];
                        snprintf(command, sizeof(command), "kill -s 12 %d", pid1);
                        system(command);
                        info = infoWrite(-1, _nomeX);


                    }
                    else if(checkValidacao  == -2)
                    {
                        printf("\nEssa posição já esta ocupada!!\n");
                        sleep(4);
                        system("clear");

                        char command[128];
                        snprintf(command, sizeof(command), "kill -s 18 %d", pid1);
                        system(command);
                        info = infoWrite(-1, _nomeX);

                    }
                }

                write(fd, info, strlen(escrever));

                if(velha >= 9)
                {
                    printf("\nJogo empatou.\n");
                    escrever[0] = '\0';
                    _datahora[0] = '\0';

                    char command1[128];
                    snprintf(command1, sizeof(command1), "kill -s 3 %d", pid1);
                    system(command1);
                    char command2[128];
                    snprintf(command2, sizeof(command2), "kill -s 3 %d", pid2);
                    system(command2);
                    info = infoWrite(2, _nomeX);
                    write(fd, info, strlen(escrever));
                    close(fd);
                    exit(EXIT_SUCCESS);
                }
            }

            if(checkValidacao  != -1  && checkValidacao  != -2)
            {
                if(pid2 != 0)
                {
                    //é sua vez
                    char command[128];
                    snprintf(command, sizeof(command), "kill -s 2 %d", pid2);
                    system(command);
                    if(pid1 != 0)
                    {
                        //espera sua vez
                        char command2[128];
                        snprintf(command2, sizeof(command2), "kill -s 1 %d", pid1);
                        system(command2);
                    }
                }
                jogar1Check = 2;
            }

        }


        if(jogar1Check == 2)
        {

            if(_fim!=0)
            {


                printf("Jogador %s é sua vez",_nomeO);
                play2();
                checkValidacao = checaJogada(x,y);
                if(tela[x][y]==' ')
                {
                    velha++;
                    tela[x][y]='O';
                    system("clear");
                    info = infoWrite(0, _nomeO);
                    verificaGanhador(pl);
                }
                else
                {

                    if(checkValidacao == -1)
                    {
                        printf("\nPosição invalida!!\n");
                        sleep(4);
                        system("clear");
                        char command[128];
                        snprintf(command, sizeof(command), "kill -s 12 %d", pid2);
                        system(command);
                        info = infoWrite(-1, _nomeO);

                    }
                    else if(checkValidacao  == -2)
                    {
                        printf("\nEssa posição já esta ocupada!!\n");
                        sleep(4);
                        system("clear");
                        char command[128];
                        snprintf(command, sizeof(command), "kill -s 18 %d", pid2);
                        system(command);
                        info = infoWrite(-1, _nomeO);

                    }


                }
                write(fd, info, strlen(escrever));
                if(velha >= 9)
                {
                    printf("\nJogo empatou.\n");
                    escrever[0] = '\0';
                    _datahora[0] = '\0';

                    char command1[128];
                    snprintf(command1, sizeof(command1), "kill -s 3 %d", pid1);
                    system(command1);
                    char command2[128];
                    snprintf(command2, sizeof(command2), "kill -s 3 %d", pid2);
                    system(command2);
                    info = infoWrite(2, _nomeO);
                    write(fd, info, strlen(escrever));
                    close(fd);
                    exit(EXIT_SUCCESS);
                }

            }

            if(checkValidacao  != -1  && checkValidacao  != -2)
            {

                if(pid1 != 0)
                {
                    char command[128];
                    snprintf(command, sizeof(command), "kill -s 10 %d", pid1);
                    system(command);
                    if(pid2 != 0)
                    {
                        char command2[128];
                        snprintf(command2, sizeof(command2), "kill -s 1 %d", pid2);
                        system(command2);
                    }
                }
                jogar1Check = 1;
            }

        }
    }

    close(fd);
    printf("Jogo finalizado\n");
    exit(EXIT_SUCCESS);
}
