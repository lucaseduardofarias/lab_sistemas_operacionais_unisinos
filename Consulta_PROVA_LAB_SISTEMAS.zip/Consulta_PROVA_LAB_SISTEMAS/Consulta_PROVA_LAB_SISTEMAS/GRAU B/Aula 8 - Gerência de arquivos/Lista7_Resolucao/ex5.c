#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define FILE_MAX_LENGTH 512

int gravar_arquivo(char *nome, char *conteudo);
void processar_arquivo(int fd, char *arq1);

int main(int argc, char* argv[])
{
    if(argc < 3){
	printf("Informe o nome dos 2 arquivos!\n");
	return 13;
    }

    int fd;
    fd = open(argv[1], O_RDONLY);

    if (fd == -1){
        printf("\nO arquivo 1 não existe.\n Informe um arquivo válido!\n");
	return 14;	
    }
    else{
        printf("\nO arquivo 1 é válido!\n Processando arquivo... \n");
        processar_arquivo(fd, argv[2]);
    }

    close(fd);
    return 0;
}

int gravar_arquivo(char *nome, char *conteudo)
{
    int fd = open(nome, O_RDWR | O_CREAT, S_IRGRP | S_IWGRP | S_IWUSR | S_IRUSR | S_IROTH | S_IWOTH);

    if (fd < 0){
        perror("\nErro na escrita.\n");
        return -1;
    }

    int length = strlen(conteudo);

    printf("\nTamanho do texto a ser gravado: %d B\n", length);

    int status = write(fd, conteudo, length);

    if (status < 0){
        perror("\nFalha na escrita do arquivo.\n");
        return -1;
    }

    close(fd);
    return fd;
}

void processar_arquivo(int fd, char *arq2)
{
    int j=0;
    int tamanho = lseek(fd, 0, SEEK_END);

    printf("\nTamanho do arquivo 1: %d B\n", tamanho);

    lseek(fd, 0, SEEK_SET);

    printf("\nConteúdo do arquivo 1:\n");

    int total_read = FILE_MAX_LENGTH;
    char buffer1[FILE_MAX_LENGTH];
    char buffer2[FILE_MAX_LENGTH];

    while (FILE_MAX_LENGTH == total_read)
    {
        total_read = read(fd, buffer1, FILE_MAX_LENGTH);

        if (FILE_MAX_LENGTH > total_read)
        {
            buffer1[total_read] = '\0';
            printf("%s", buffer1);
            break;
        }
        else
        {
            printf("%s", buffer1);
        }
    }

    for(int i=0;i<tamanho;i++){
	if (buffer1[i]!='\n' && buffer1[i]!=' ') {
	    buffer2[j++]=(char)buffer1[i];
	}
    }

    gravar_arquivo(arq2, buffer2);
    printf("\nConteúdo do arquivo 2:\n");
    printf("%s \n\n", buffer2);

}
