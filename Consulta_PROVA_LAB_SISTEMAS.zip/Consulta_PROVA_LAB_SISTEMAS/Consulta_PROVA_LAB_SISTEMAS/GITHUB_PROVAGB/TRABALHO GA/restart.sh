#!/bin/bash

clear;
gcc main.c -o main;
./main;
exit 0;