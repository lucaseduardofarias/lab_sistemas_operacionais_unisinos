#!/bin/bash
echo -e "Digite qualquer tecla para prosseguir: \n";
read opcao;
echo -e "O programa para exibição do status da RAM será executado: \n";
gcc -Wall Ex10.c -o Ex10;
./Ex10;
          
